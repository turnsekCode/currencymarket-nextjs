exports.id = 115;
exports.ids = [115];
exports.modules = {

/***/ 3568:
/***/ ((module) => {

// Exports
module.exports = {
	"banderas_inferior": "banderasInferior_banderas_inferior___02sy",
	"contenedor_banderas_inferior": "banderasInferior_contenedor_banderas_inferior__21nk8",
	"izq": "banderasInferior_izq__QD1Ff"
};


/***/ }),

/***/ 9621:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_banderas": "banderasSuperior_contenedor_banderas__Z6M0m"
};


/***/ }),

/***/ 6297:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_llamar_fijo": "botonLlamarFijo_contenedor_llamar_fijo__3kyyM"
};


/***/ }),

/***/ 8450:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_footer": "footer_contenedor_footer__Xyjg4"
};


/***/ }),

/***/ 6394:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_section_footer": "footerPasos_contenedor_section_footer__enWCr",
	"titulo_superior_footer": "footerPasos_titulo_superior_footer__9wuxY",
	"titulo_inferior_footer": "footerPasos_titulo_inferior_footer__eNyNN",
	"contenedor_cajas_pasos": "footerPasos_contenedor_cajas_pasos__FThbL",
	"caja_pasos": "footerPasos_caja_pasos__3lHTi",
	"barra_inferior": "footerPasos_barra_inferior__Mmk_i"
};


/***/ }),

/***/ 8966:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_header": "header_contenedor_header__SFO3Y",
	"contenedor_padding": "header_contenedor_padding__SWlxP",
	"contenedor_llamar": "header_contenedor_llamar__AFKP2",
	"logo": "header_logo__xDpi_",
	"contenedor_logos": "header_contenedor_logos__kS1mF"
};


/***/ }),

/***/ 1898:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_seccion_footer": "seccionFooter_contenedor_seccion_footer__AAOX9",
	"logo_footer": "seccionFooter_logo_footer__ThMtc",
	"contenedor_links_footer": "seccionFooter_contenedor_links_footer__DJrPb",
	"links_footer": "seccionFooter_links_footer__G40Vq",
	"parrafo_footer": "seccionFooter_parrafo_footer__9ykRs",
	"barra_inferior": "seccionFooter_barra_inferior__lrZW1"
};


/***/ }),

/***/ 1828:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_conversor": "Home_contenedor_conversor__LRn5_",
	"bloque_der": "Home_bloque_der__wJGlW",
	"separador_section": "Home_separador_section__lgYvy",
	"layout": "Home_layout__iYGnf",
	"contenedor_privacidad": "Home_contenedor_privacidad__zkVOC",
	"mapboxgl-ctrl-group": "Home_mapboxgl-ctrl-group__RP9CX",
	"scroll-to-top": "Home_scroll-to-top__bmIZ_"
};


/***/ }),

/***/ 8115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Contenedor)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/header/header.module.css
var header_module = __webpack_require__(8966);
var header_module_default = /*#__PURE__*/__webpack_require__.n(header_module);
// EXTERNAL MODULE: external "@mui/icons-material/LocalPhone"
var LocalPhone_ = __webpack_require__(550);
var LocalPhone_default = /*#__PURE__*/__webpack_require__.n(LocalPhone_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/assets/logo_quickgold.png
/* harmony default export */ const logo_quickgold = ({"src":"/_next/static/media/logo_quickgold.57953c16.png","height":60,"width":310,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAQElEQVR4nGP8tZXBlMXtmwgjC6f0////ORkYGFiB+BUQiwCxAOOvDQxGLN4/NBlZ2LWBCm4DBfmAWBmIrwMxIwBM+w/hGTMH4AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/componentes/header/Header.js







const Header = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (header_module_default()).contenedor_header,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (header_module_default()).contenedor_padding,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (header_module_default()).contenedor_logos,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: logo_quickgold,
                                alt: "Logo Quickgold",
                                width: 170,
                                height: 33
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "/",
                            className: (header_module_default()).logo,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "CURRENCY"
                                }),
                                "MARKET\xae"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (header_module_default()).contenedor_llamar,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        href: "tel:672616533",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((LocalPhone_default()), {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                children: [
                                    "LLAMAR ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "A CURRENCY MARKET"
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const header_Header = (Header);

// EXTERNAL MODULE: ./src/componentes/banderas_superior/banderasSuperior.module.css
var banderasSuperior_module = __webpack_require__(9621);
var banderasSuperior_module_default = /*#__PURE__*/__webpack_require__.n(banderasSuperior_module);
;// CONCATENATED MODULE: ./public/assets/esquina-sup-izquierda.png
/* harmony default export */ const esquina_sup_izquierda = ({"src":"/_next/static/media/esquina-sup-izquierda.44e39f22.png","height":100,"width":288,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAX0lEQVR42mMoLJp0Kr9w6umCoulAPO1MeeWsa/WN86/GxvecYGDIDmYoLZ90NTml4UJKWs/5nLwp1xgY8lNMLKu12cSK5BlAAKijNyAwZZWZReJhBoYQHwYk4OLeyAQAdBYjFiT/J40AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/assets/esquina-sup-derecha.png
/* harmony default export */ const esquina_sup_derecha = ({"src":"/_next/static/media/esquina-sup-derecha.37630915.png","height":100,"width":298,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAbklEQVR4nAFjAJz/AeRxd1YJQD11APz8DQADA/8CCgr1AAIC/wMBAQD19/f/AeyrrgDzgZAkB1xPEgEFBSkHJiR1AQkI/AEAAQDa4eEGAe61twLxhZH+CFBGAAo4NgDxoadEC0VAe/sFBevazc7UxsElNQajwtEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./src/componentes/banderas_superior/BanderasSuperior.js






const BanderasSuperior = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (banderasSuperior_module_default()).contenedor_banderas,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: (banderasSuperior_module_default()).imagen_bandera_izq,
                src: esquina_sup_izquierda,
                alt: "banderas"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: (banderasSuperior_module_default()).imagen_bandera_der,
                src: esquina_sup_derecha,
                alt: "banderas"
            })
        ]
    });
};
/* harmony default export */ const banderas_superior_BanderasSuperior = (BanderasSuperior);

// EXTERNAL MODULE: ./src/componentes/footer_pasos/footerPasos.module.css
var footerPasos_module = __webpack_require__(6394);
var footerPasos_module_default = /*#__PURE__*/__webpack_require__.n(footerPasos_module);
;// CONCATENATED MODULE: ./public/assets/Rectangle 46.png
/* harmony default export */ const Rectangle_46 = ({"src":"/_next/static/media/Rectangle 46.a26545fe.png","height":4,"width":2000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAEElEQVR4nGP89++fJAMeAABfXQMV+j0vwAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":1});
;// CONCATENATED MODULE: ./src/componentes/footer_pasos/FooterPasos.js





const FooterPasos = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (footerPasos_module_default()).contenedor_section_footer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                className: (footerPasos_module_default()).titulo_superior_footer,
                children: [
                    "Cambia Euros a D\xf3lares en ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "3 pasos:"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (footerPasos_module_default()).contenedor_cajas_pasos,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footerPasos_module_default()).caja_pasos,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: "1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                children: "LLAMA"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "a tu tienda m\xe1s cercana"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footerPasos_module_default()).caja_pasos,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: "2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                children: "RESERVA"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "la cantidad de d\xf3lares que necesitas"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footerPasos_module_default()).caja_pasos,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: "3"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                children: "RECOGE"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "tus d\xf3lares"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                className: (footerPasos_module_default()).titulo_inferior_footer,
                children: [
                    "DE FORMA ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "R\xc1PIDA Y SEGURA"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: (footerPasos_module_default()).barra_inferior,
                src: Rectangle_46,
                alt: "barra",
                width: "0",
                height: "0"
            })
        ]
    });
};
/* harmony default export */ const footer_pasos_FooterPasos = (FooterPasos);

// EXTERNAL MODULE: ./src/componentes/seccion_footer/seccionFooter.module.css
var seccionFooter_module = __webpack_require__(1898);
var seccionFooter_module_default = /*#__PURE__*/__webpack_require__.n(seccionFooter_module);
;// CONCATENATED MODULE: ./src/componentes/seccion_footer/SeccionFooter.js






const SeccionFooter = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (seccionFooter_module_default()).contenedor_seccion_footer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                className: (seccionFooter_module_default()).logo_footer,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "CURRENCY"
                    }),
                    "MARKET\xae"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (seccionFooter_module_default()).contenedor_links_footer,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/privacidad",
                        className: (seccionFooter_module_default()).links_footer,
                        children: "POL\xcdTICA DE PRIVACIDAD"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (seccionFooter_module_default()).links_footer,
                        href: "https://quickgold.es/",
                        target: "_BLANK",
                        rel: "noreferrer",
                        children: "CON\xd3CENOS"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: (seccionFooter_module_default()).barra_inferior,
                src: Rectangle_46,
                alt: "barra"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: (seccionFooter_module_default()).parrafo_footer,
                children: "\xa9 2023 Currencymarket | CURRENCY MARKET S.A. - A98914633 - RONDA AUGUSTE Y LOUIS LUMIERE, 23, NAVE 9 46980 PATERNA, VALENCIA - administracion@currencymarket.es - 900 373 649 Registro Mercantil de Valencia , Tomo 9220, Libro 6503, Folio 215, Hoja V-140170, Inscripci\xf3n 2\xaa."
            })
        ]
    });
};
/* harmony default export */ const seccion_footer_SeccionFooter = (SeccionFooter);

// EXTERNAL MODULE: ./src/componentes/footer/footer.module.css
var footer_module = __webpack_require__(8450);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
;// CONCATENATED MODULE: ./src/componentes/footer/Footer.js





const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: (footer_module_default()).contenedor_footer,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(footer_pasos_FooterPasos, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(seccion_footer_SeccionFooter, {})
        ]
    });
};
/* harmony default export */ const footer_Footer = (Footer);

// EXTERNAL MODULE: ./src/componentes/banderas_inferior/banderasInferior.module.css
var banderasInferior_module = __webpack_require__(3568);
var banderasInferior_module_default = /*#__PURE__*/__webpack_require__.n(banderasInferior_module);
;// CONCATENATED MODULE: ./public/assets/bandera_footer_izq.png
/* harmony default export */ const bandera_footer_izq = ({"src":"/_next/static/media/bandera_footer_izq.60455709.png","height":480,"width":236,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAgklEQVR42mNIz+2IYwCCSVOXMjOAQHXDtC8r1h5WA7EXLdvFxFDTMPt/YcnMSpBAasUcFobY8on/49oWN4IEFpb1sTFMMwz7fyw5fyUDDPzftv3P/6Li/3+iYhaABX6eOvP/V03Nn/9tHf//BQR2Mvxasfr/94amv39nzPz/b/bcuwAQATueSFgzDQAAAABJRU5ErkJggg==","blurWidth":4,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/bandera_footer_der.png
/* harmony default export */ const bandera_footer_der = ({"src":"/_next/static/media/bandera_footer_der.87c0d24f.png","height":480,"width":236,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAgElEQVR42mMAgYlTlzKD6LTc9jiGRct2MYE4K9YeVqtumPaFIaViDgtIoLBkZmVNw+z/DAvL+thAAnFtixpjyyf+Z4CBY8n5K6cZhUEE/kTFLPhfVPT//7btfxj+BQR2/m/r+P+rpubPz9Nn/jP8mz337t8ZM/9/b2j++2vF6v8AbAg7m3aJdVMAAAAASUVORK5CYII=","blurWidth":4,"blurHeight":8});
;// CONCATENATED MODULE: ./src/componentes/banderas_inferior/BanderasInferior.js






const BanderasInferior = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (banderasInferior_module_default()).contenedor_banderas_inferior,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: `${(banderasInferior_module_default()).banderas_inferior} ${(banderasInferior_module_default()).izq}`,
                src: bandera_footer_izq,
                alt: "bandera"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: (banderasInferior_module_default()).banderas_inferior,
                src: bandera_footer_der,
                alt: "bandera"
            })
        ]
    });
};
/* harmony default export */ const banderas_inferior_BanderasInferior = (BanderasInferior);

// EXTERNAL MODULE: ./src/componentes/boton_llamar_fijo/botonLlamarFijo.module.css
var botonLlamarFijo_module = __webpack_require__(6297);
var botonLlamarFijo_module_default = /*#__PURE__*/__webpack_require__.n(botonLlamarFijo_module);
;// CONCATENATED MODULE: ./src/componentes/boton_llamar_fijo/BotonLlamarFijo.js




const BotonLlamarFijo = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (botonLlamarFijo_module_default()).contenedor_llamar_fijo,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
            href: "tel:672616533",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((LocalPhone_default()), {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                    children: [
                        "LLAMAR ",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "A CURRENCY MARKET"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const boton_llamar_fijo_BotonLlamarFijo = (BotonLlamarFijo);

// EXTERNAL MODULE: external "react-scroll-to-top"
var external_react_scroll_to_top_ = __webpack_require__(5337);
var external_react_scroll_to_top_default = /*#__PURE__*/__webpack_require__.n(external_react_scroll_to_top_);
// EXTERNAL MODULE: ./src/styles/Home.module.css
var Home_module = __webpack_require__(1828);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
;// CONCATENATED MODULE: ./src/componentes/contenedor/Contenedor.js








function Contenedor({ children  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(banderas_superior_BanderasSuperior, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: (Home_module_default()).layout,
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((external_react_scroll_to_top_default()), {
                smooth: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer_Footer, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(banderas_inferior_BanderasInferior, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(boton_llamar_fijo_BotonLlamarFijo, {})
        ]
    });
}


/***/ })

};
;