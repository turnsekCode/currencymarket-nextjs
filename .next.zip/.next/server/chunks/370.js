exports.id = 370;
exports.ids = [370];
exports.modules = {

/***/ 8690:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_conversor_divisa": "conversor_contenedor_conversor_divisa__sBLew",
	"contenedor_input": "conversor_contenedor_input__AJNyW",
	"info_precio": "conversor_info_precio__QRrSw",
	"bloque_der_moneda": "conversor_bloque_der_moneda__DcsH0",
	"bloque_izq_moneda": "conversor_bloque_izq_moneda__HgHHQ",
	"contenedor_conversor_inferior": "conversor_contenedor_conversor_inferior__fxUgH",
	"bloque_der_moneda_inferior": "conversor_bloque_der_moneda_inferior__yi_wy",
	"input_dolar": "conversor_input_dolar__lcE9v"
};


/***/ }),

/***/ 9849:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_mapa_usa": "conversorGoogle_contenedor_mapa_usa__TDAxz",
	"contenedor_precio_google": "conversorGoogle_contenedor_precio_google__zhaE7",
	"contenedor_texto_inferior": "conversorGoogle_contenedor_texto_inferior__yBWxD",
	"logo_google": "conversorGoogle_logo_google____Kh0",
	"titulo_precio": "conversorGoogle_titulo_precio__TtxOW",
	"contenedor_parrafo": "conversorGoogle_contenedor_parrafo__vJEBt",
	"boton_abrir_popup": "conversorGoogle_boton_abrir_popup__kiGyD",
	"separador_section": "conversorGoogle_separador_section__OBAzT",
	"contenedor_google": "conversorGoogle_contenedor_google__pVlYS",
	"iframe_mapa": "conversorGoogle_iframe_mapa__xh1zG"
};


/***/ }),

/***/ 1976:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo-Google_1.da3ff55d.png","height":120,"width":214,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAYklEQVR42mOQbv0mzdD+V4gBHfxnYIQw2n4kmrZ9CfxomuH1fwaD2/vdSS4M7f+dGqbUVf63YAhgYGj75eDY+sn3m25EKFBB6OtduWEMbf9aJ3YsLP5vxBDFgA2oNX+TgbEBF7Ak66Ps+lgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 8370:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ conversor_google_ConversorGoogle)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/conversor_google/conversorGoogle.module.css
var conversorGoogle_module = __webpack_require__(9849);
var conversorGoogle_module_default = /*#__PURE__*/__webpack_require__.n(conversorGoogle_module);
// EXTERNAL MODULE: ./public/assets/logo-Google_1.png
var logo_Google_1 = __webpack_require__(1976);
;// CONCATENATED MODULE: ./public/assets/mapa_usa.png
/* harmony default export */ const mapa_usa = ({"src":"/_next/static/media/mapa_usa.b43c10a3.png","height":626,"width":899,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAXUlEQVR42k3NSw6EMAwD0N7/skzJxwlJ0wlCQliWN2/hIXC/opfE3or6iMy9d1WtqlxL1MwD9oFnM1eHBINYs+2TK+IGVp8nE0tzvwEQhcAbrO1kHJOOyT/SSUpifyPyi+uxRWB8AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":6});
// EXTERNAL MODULE: ./src/componentes/conversor/conversor.module.css
var conversor_module = __webpack_require__(8690);
var conversor_module_default = /*#__PURE__*/__webpack_require__.n(conversor_module);
;// CONCATENATED MODULE: ./src/componentes/conversor/Conversor.js



const Conversor = ()=>{
    const [data, setData] = (0,external_react_.useState)([]);
    const [loading, setLoading] = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        fetch("https://docs.google.com/spreadsheets/d/e/2PACX-1vTMm1jsqMJYy06TXURw9EVyFqalRHk_m0vTJmoGjBd2ss0YIG0mi8oifYw2CvMsl5R4K0rHrJ5CsI2x/pub?gid=0&single=true&output=csv").then((response)=>response.json()).then((data)=>{
            setData(data);
            setLoading(true);
        });
    }, []);
    //const [valorMoneda, setValorMoneda] = useState("0");
    const refInput1 = (0,external_react_.useRef)();
    const refInput2 = (0,external_react_.useRef)();
    const replace = data.toString().replace(",", ".");
    const calcularCambio = (event)=>{
        const { id , value: valor  } = event.target;
        let cambio = 0;
        if (id === "input-izquierdo") {
            // si cambia el input izquierdo, calcula el derecho
            cambio = valor * replace;
            refInput2.current.value = cambio.toFixed(2);
        } else {
            // si cambia el input derecho, calcula el izquierdo
            cambio = valor / replace;
            refInput1.current.value = cambio.toFixed(2);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (conversor_module_default()).contenedor_conversor_divisa,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                    children: [
                        "Conversor ",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "de divisa"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (conversor_module_default()).contenedor_conversor_inferior,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (conversor_module_default()).contenedor_input,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (conversor_module_default()).bloque_der_moneda_inferior,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "EUR"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (conversor_module_default()).bloque_izq_moneda,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    id: "input-derecho",
                                    ref: refInput2,
                                    type: "text",
                                    pattern: "[0-9]*",
                                    placeholder: "Cantidad",
                                    inputMode: "numeric",
                                    defaultValue: "",
                                    onChange: calcularCambio
                                }),
                                " ",
                                "€",
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (conversor_module_default()).info_precio,
                                    children: "Sin comisiones"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (conversor_module_default()).contenedor_input,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (conversor_module_default()).bloque_der_moneda,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "USA"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (conversor_module_default()).bloque_izq_moneda,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                id: "input-izquierdo",
                                ref: refInput1,
                                type: "text",
                                className: (conversor_module_default()).input_dolar,
                                pattern: "[0-9]*",
                                placeholder: "0.00",
                                inputMode: "numeric",
                                onChange: calcularCambio,
                                readOnly: true
                            }),
                            "$",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: (conversor_module_default()).info_precio,
                                children: [
                                    "1$ = ",
                                    loading ? replace / 1 : "Cargando...",
                                    " €"
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const conversor_Conversor = (Conversor);

;// CONCATENATED MODULE: ./public/assets/Rectangle 34.png
/* harmony default export */ const Rectangle_34 = ({"src":"/_next/static/media/Rectangle 34.2f3af5d8.png","height":20,"width":2000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABAQMAAADZzn0AAAAABlBMVEUAMHMAMHIcgSjYAAAAAnRSTlMfHzbBzlMAAAANSURBVHjaAQIA/f8AnwChAKB6kly2AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":1});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/componentes/conversor_google/ConversorGoogle.js








const ConversorGoogle = ({ open , setOpen  })=>{
    const popupOpen = ()=>{
        setOpen(true);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (conversorGoogle_module_default()).contenedor_precio_google,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (conversorGoogle_module_default()).contenedor_conversor,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                className: (conversorGoogle_module_default()).titulo_precio,
                                children: [
                                    "Te damos los ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "d\xf3lares "
                                    }),
                                    "al precio que marque",
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: (conversorGoogle_module_default()).logo_google,
                                        src: logo_Google_1/* default */.Z,
                                        alt: "logo google"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (conversorGoogle_module_default()).boton_abrir_popup,
                                onClick: popupOpen,
                                children: "Compru\xe9balo t\xfa mismo"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(conversor_Conversor, {})
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (conversorGoogle_module_default()).contenedor_mapa_usa,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: mapa_usa,
                            alt: "mapa usa",
                            width: 388,
                            height: 270,
                            priority: true
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (conversorGoogle_module_default()).contenedor_texto_inferior,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (conversorGoogle_module_default()).separador_section,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: Rectangle_34,
                        alt: ""
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const conversor_google_ConversorGoogle = (ConversorGoogle);


/***/ })

};
;