exports.id = 975;
exports.ids = [975];
exports.modules = {

/***/ 167:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_popup": "popupGoogle_contenedor_popup__lSxi1",
	"popup_activo": "popupGoogle_popup_activo__4Svqn",
	"contenedor_google": "popupGoogle_contenedor_google__59wKY",
	"boton_cerrar_popup": "popupGoogle_boton_cerrar_popup__ii9rP",
	"iframe_mapa": "popupGoogle_iframe_mapa__DHPGX"
};


/***/ }),

/***/ 7975:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _popupGoogle_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(167);
/* harmony import */ var _popupGoogle_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_popupGoogle_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6380);
/* harmony import */ var _mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_2__);




const PopupGoogle = ({ open , setOpen  })=>{
    const popupCerrar = ()=>{
        setOpen(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: open ? `${(_popupGoogle_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedor_popup)} ${(_popupGoogle_module_css__WEBPACK_IMPORTED_MODULE_3___default().popup_activo)}` : `${(_popupGoogle_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedor_popup)}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_popupGoogle_module_css__WEBPACK_IMPORTED_MODULE_3___default().contenedor_google),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                    src: "https://www.google.com/search?q=euro+cotizacion&igu=1&ei=igfJY8XFFJaW9u8Pweik4AM&ved=0ahUKEwjFsrq6o9P8AhUWi_0HHUE0CTwQ4dUDCA8&uact=5&oq=euro+cotizacion&gs_lcp=Cgxnd3Mtd2l6LXNlcnAQAzIPCAAQsQMQgwEQQxBGEIICMgcIABCABBANMgcIABCABBANMgQIABBDMgYIABAHEB4yBwgAEIAEEA0yBggAEAcQHjIHCAAQgAQQDTIHCAAQgAQQDTIHCAAQgAQQDUoECEEYAEoECEYYAFAAWJAGYPcRaABwAXgAgAFsiAGoA5IBAzAuNJgBAKABAcABAQ&sclient=gws-wiz-serp",
                    name: "myIFrame",
                    frameBorder: "0",
                    scrolling: "no",
                    title: "mapa google",
                    className: (_popupGoogle_module_css__WEBPACK_IMPORTED_MODULE_3___default().iframe_mapa)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_popupGoogle_module_css__WEBPACK_IMPORTED_MODULE_3___default().boton_cerrar_popup),
                    onClick: popupCerrar,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_2___default()), {})
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PopupGoogle);


/***/ })

};
;