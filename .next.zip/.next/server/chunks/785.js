exports.id = 785;
exports.ids = [785];
exports.modules = {

/***/ 2103:
/***/ ((module) => {

// Exports
module.exports = {
	"img_stars": "accordion2_img_stars__0kPDA",
	"imgValoracion": "accordion2_imgValoracion__gOsEr",
	"logo_google": "accordion2_logo_google__UlGkE",
	"contenedor_google_accordion": "accordion2_contenedor_google_accordion__84Pyn",
	"nombre_tienda": "accordion2_nombre_tienda__Kgwt2",
	"contenedor_resenas": "accordion2_contenedor_resenas___dNYL",
	"numero_reviews": "accordion2_numero_reviews__RGQo1",
	"contacto_accordion": "accordion2_contacto_accordion__zZ_w1",
	"direccion_accordion": "accordion2_direccion_accordion__W08K3",
	"telefono_accordion": "accordion2_telefono_accordion__zAa_l",
	"contenedor_horarios": "accordion2_contenedor_horarios__Mhzjs",
	"contenedor_accordion": "accordion2_contenedor_accordion__9Ppk_",
	"css-1fjvggn-MuiPaper-root-MuiAccordion-root": "accordion2_css-1fjvggn-MuiPaper-root-MuiAccordion-root__qMLLa",
	"contenedor_accordion2": "accordion2_contenedor_accordion2__yatZX",
	"contenedor_accordion2_active": "accordion2_contenedor_accordion2_active__glu5Q",
	"cabecera_estrellas": "accordion2_cabecera_estrellas__ynE9o",
	"cabecera_estrellas_active": "accordion2_cabecera_estrellas_active__iFh2t",
	"contenedor_titulo_accordion": "accordion2_contenedor_titulo_accordion__ZEzgo",
	"active": "accordion2_active__p9OEv",
	"boton_cierre": "accordion2_boton_cierre__Qo8FU"
};


/***/ }),

/***/ 8924:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_mapa": "mapa_contenedor_mapa__gHmtH",
	"mapa": "mapa_mapa__hf6yQ",
	"market_img": "mapa_market_img__X2Z6p",
	"titulo_mapa": "mapa_titulo_mapa__bMe_o",
	"contenedor_info_mapa": "mapa_contenedor_info_mapa__yLAkb",
	"boton_encontrar": "mapa_boton_encontrar__JUEzy",
	"conenedor_info_tienda": "mapa_conenedor_info_tienda__OxFY7",
	"conenedor_info_tienda_show": "mapa_conenedor_info_tienda_show__bYwcp",
	"nombre_ciudad": "mapa_nombre_ciudad___byOz",
	"item": "mapa_item__rZZl1",
	"popup-delicias": "mapa_popup-delicias___y0CP",
	"mapboxgl-popup-close-button": "mapa_mapboxgl-popup-close-button__RFRUR",
	"nombre_ciudad_popup": "mapa_nombre_ciudad_popup__MGnB8",
	"direccion_popup": "mapa_direccion_popup__E_EeR",
	"contenedor_popuop": "mapa_contenedor_popuop__CAyQt",
	"telefono_popup": "mapa_telefono_popup__2D0VS",
	"boton_como_llegar": "mapa_boton_como_llegar__qyXOK",
	"boton_ver_mas": "mapa_boton_ver_mas__wFTCt",
	"reset_map": "mapa_reset_map__i0qI8"
};


/***/ }),

/***/ 2785:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ mapa_Mapa)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/componentes/mapa/mapa.module.css
var mapa_module = __webpack_require__(8924);
var mapa_module_default = /*#__PURE__*/__webpack_require__.n(mapa_module);
// EXTERNAL MODULE: ./node_modules/animate.css/animate.css
var animate = __webpack_require__(5544);
// EXTERNAL MODULE: external "react-map-gl"
var external_react_map_gl_ = __webpack_require__(5372);
var external_react_map_gl_default = /*#__PURE__*/__webpack_require__.n(external_react_map_gl_);
// EXTERNAL MODULE: ./public/assets/logo-Google_1.png
var logo_Google_1 = __webpack_require__(1976);
// EXTERNAL MODULE: external "@mui/icons-material/ArrowForwardIos"
var ArrowForwardIos_ = __webpack_require__(1658);
var ArrowForwardIos_default = /*#__PURE__*/__webpack_require__.n(ArrowForwardIos_);
// EXTERNAL MODULE: ./src/componentes/accordion/accordion2.module.css
var accordion2_module = __webpack_require__(2103);
var accordion2_module_default = /*#__PURE__*/__webpack_require__.n(accordion2_module);
// EXTERNAL MODULE: external "@mui/icons-material/HighlightOff"
var HighlightOff_ = __webpack_require__(6380);
var HighlightOff_default = /*#__PURE__*/__webpack_require__.n(HighlightOff_);
// EXTERNAL MODULE: external "react-scroll"
var external_react_scroll_ = __webpack_require__(3094);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/componentes/accordion/Accordion2.js








const Accordion2 = ({ showPopup , setShowPopup , onSelectAlcala , onSelectDelicias , onSelectTetuan , onSelectBernardo , onSelectTirso , onSelectCaminos , onSelectSantantoni , tirso , alcala , bernardo , caminos , tetuan , delicias , santantoni  })=>{
    const horarios = santantoni?.result?.opening_hours?.weekday_text;
    const listaHorarios = horarios?.map((number, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
            className: `dia_${i++}`,
            children: number
        }, i));
    const resenas = santantoni?.result?.rating;
    if (resenas > 4.7) {
        var img_valoracion = 69;
    } else if (resenas < 4.8 && resenas < 4.3) {
        var img_valoracion = 62;
    } else if (resenas < 4.4 && resenas < 3.7) {
        var img_valoracion = 55;
    } else if (resenas < 3.8 && resenas < 3.3) {
        var img_valoracion = 48;
    } else if (resenas < 3.4 && resenas < 2.7) {
        var img_valoracion = 41;
    } else if (resenas < 2.8 && resenas < 2.3) {
        var img_valoracion = 34;
    } else if (resenas < 2.4 && resenas < 1.7) {
        var img_valoracion = 27;
    } else if (resenas < 1.8 && resenas < 1.3) {
        var img_valoracion = 20;
    } else if (resenas < 1.4 && resenas < 0.7) {
        var img_valoracion = 13;
    }
    const toggleTab = (index)=>{
        setShowPopup(index);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                id: "delicias",
                className: showPopup === 7 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                        to: "contendor_mapa",
                        smooth: true,
                        offset: -110,
                        spy: true,
                        duration: 500,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            onClick: ()=>{
                                toggleTab(7);
                                onSelectSantantoni();
                            },
                            className: (accordion2_module_default()).nombre_tienda,
                            children: santantoni?.result?.name
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 7 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 7 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: santantoni?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: santantoni?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3g7uDF2",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: santantoni?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${santantoni?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: santantoni?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                id: "delicias",
                className: showPopup === 1 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                        to: "contendor_mapa",
                        smooth: true,
                        offset: -110,
                        spy: true,
                        duration: 500,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            onClick: ()=>{
                                toggleTab(1);
                                onSelectDelicias();
                            },
                            className: (accordion2_module_default()).nombre_tienda,
                            children: delicias?.result?.name
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 1 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 1 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: delicias?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: delicias?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3X3XYRj",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: delicias?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${delicias?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: delicias?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "contendor_mapa",
                smooth: true,
                offset: -110,
                duration: 500,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        toggleTab(4);
                        onSelectTirso();
                    },
                    id: "tirso",
                    className: showPopup === 4 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: (accordion2_module_default()).nombre_tienda,
                            children: tirso?.result?.name
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 4 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 4 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: tirso?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: tirso?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3tFiXwm",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: tirso?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${tirso?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: tirso?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "contendor_mapa",
                smooth: true,
                offset: -110,
                duration: 500,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        toggleTab(3);
                        onSelectCaminos();
                    },
                    id: "caminos",
                    className: showPopup === 3 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: (accordion2_module_default()).nombre_tienda,
                            children: caminos?.result?.name
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 3 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 3 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: caminos?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: caminos?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3EFq1iI",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: caminos?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${caminos?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: caminos?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "contendor_mapa",
                smooth: true,
                offset: -110,
                duration: 500,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        toggleTab(2);
                        onSelectBernardo();
                    },
                    id: "bernardo",
                    className: showPopup === 2 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: (accordion2_module_default()).nombre_tienda,
                            children: bernardo?.result?.name
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 2 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 2 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: bernardo?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: bernardo?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3V13uCi",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: bernardo?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${bernardo?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: bernardo?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "contendor_mapa",
                smooth: true,
                offset: -110,
                duration: 500,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        toggleTab(6);
                        onSelectAlcala();
                    },
                    id: "alcala",
                    className: showPopup === 6 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: (accordion2_module_default()).nombre_tienda,
                            children: alcala?.result?.name
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 6 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 6 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: alcala?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: alcala?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3THXcpZ",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: alcala?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${alcala?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: alcala?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "contendor_mapa",
                smooth: true,
                offset: -110,
                duration: 500,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        //handleChange(5);
                        //setShowPopup(null);
                        toggleTab(5);
                        onSelectTetuan();
                    },
                    id: "tetuan",
                    className: showPopup === 5 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: (accordion2_module_default()).nombre_tienda,
                            children: tetuan?.result?.name
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 5 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 5 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: tetuan?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: tetuan?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3EgcXPx",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: tetuan?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${tetuan?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: tetuan?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const accordion_Accordion2 = (Accordion2);

;// CONCATENATED MODULE: ./src/componentes/mapa/Mapa.js







const Mapa = ({ tirso , alcala , bernardo , caminos , tetuan , delicias , santantoni  })=>{
    const [showPopup, setShowPopup] = (0,external_react_.useState)(null);
    const [viewState, setViewState] = (0,external_react_.useState)({
        longitude: -0.8003027,
        latitude: 40.9339916,
        zoom: 5,
        cooperativeGestures: true
    });
    const toggleTab = (index)=>{
        setShowPopup(index);
    };
    const mapRef = (0,external_react_.useRef)();
    const onSelectSantantoni = ()=>{
        mapRef.current?.flyTo({
            center: [
                2.1629099,
                41.3921409
            ],
            duration: 1500,
            zoom: 12
        });
    };
    const onSelectDelicias = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.6951906,
                40.4211045
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const onSelectTirso = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.705431599999997,
                40.4221929
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const onSelectTetuan = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.698444600000016,
                40.4703827
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const onSelectAlcala = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.665292000000022,
                40.439553
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const onSelectBernardo = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.7073656999999685,
                40.4332377
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const onSelectCaminos = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.7039902999999867,
                40.4588839
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const resetMap = ()=>{
        mapRef.current?.flyTo({
            center: [
                -0.8003027,
                40.9339916
            ],
            duration: 1500,
            zoom: 5
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                className: (mapa_module_default()).titulo_mapa,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "\xbfD\xf3nde cambiar euros a d\xf3lares?"
                    }),
                    " Casas de Cambio en Barcelona y Madrid"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "contendor_mapa",
                className: (mapa_module_default()).contenedor_mapa,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_map_gl_default()), {
                    ref: mapRef,
                    ...viewState,
                    onMove: (evt)=>setViewState(evt.viewState),
                    className: (mapa_module_default()).mapa,
                    mapStyle: "mapbox://styles/mapbox/streets-v9",
                    mapboxAccessToken: "pk.eyJ1IjoicXVpY2tnb2wiLCJhIjoiY2xhbGNvcHAyMDRyNjNwbWthcm1zMm9nbyJ9.tmZYhqn4Z6U3fcCZH647Zw",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.FullscreenControl, {}),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.GeolocateControl, {}),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.NavigationControl, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: (mapa_module_default()).reset_map,
                            onClick: ()=>{
                                resetMap();
                                setShowPopup(false);
                            },
                            children: "Reset Map"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: 2.1629099,
                            latitude: 41.3821409,
                            onClick: ()=>{
                                toggleTab(7);
                                onSelectSantantoni();
                            }
                        }),
                        showPopup === 7 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -25
                            },
                            longitude: 2.1629099,
                            className: (mapa_module_default()).popup,
                            latitude: 41.3821409,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (mapa_module_default()).contenedor_popuop,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Sant Antoni"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3g7uDF2",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: (mapa_module_default()).direccion_popup,
                                        children: santantoni.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3g7uDF2",
                                        rel: "noreferrer",
                                        ƒ: true,
                                        className: (mapa_module_default()).boton_como_llegar,
                                        target: "_blank",
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${santantoni.result?.international_phone_number}`,
                                        className: (mapa_module_default()).telefono_popup,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            santantoni.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (mapa_module_default()).boton_ver_mas,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "delicias",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.6951906,
                            latitude: 40.4011045,
                            onClick: ()=>{
                                toggleTab(1);
                                onSelectDelicias();
                            }
                        }),
                        showPopup === 1 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -25
                            },
                            longitude: -3.6951906,
                            className: "{styles.popup}",
                            latitude: 40.4011045,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (mapa_module_default()).contenedor_popuop,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Delicias"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3X3XYRj",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: (mapa_module_default()).direccion_popup,
                                        children: delicias.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3X3XYRj",
                                        rel: "noreferrer",
                                        ƒ: true,
                                        className: (mapa_module_default()).boton_como_llegar,
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${delicias.result?.international_phone_number}`,
                                        className: (mapa_module_default()).telefono_popup,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            delicias.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (mapa_module_default()).boton_ver_mas,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "delicias",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.7073656999999685,
                            latitude: 40.4232377,
                            onClick: ()=>{
                                toggleTab(2);
                                onSelectBernardo();
                            }
                        }),
                        showPopup === 2 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -35
                            },
                            longitude: -3.7073656999999685,
                            latitude: 40.4232377,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (mapa_module_default()).contenedor_popuop,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "San Bernardo"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3V13uCi",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: (mapa_module_default()).direccion_popup,
                                        children: bernardo.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3V13uCi",
                                        rel: "noreferrer",
                                        className: (mapa_module_default()).boton_como_llegar,
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${bernardo.result?.international_phone_number}`,
                                        className: (mapa_module_default()).telefono_popup,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            bernardo.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (mapa_module_default()).boton_ver_mas,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "bernardo",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.7039902999999867,
                            latitude: 40.4488839,
                            onClick: ()=>{
                                toggleTab(3);
                                onSelectCaminos();
                            }
                        }),
                        showPopup === 3 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -35
                            },
                            longitude: -3.7039902999999867,
                            latitude: 40.4488839,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (mapa_module_default()).contenedor_popuop,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Cuatro Caminos"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3EFq1iI",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: (mapa_module_default()).direccion_popup,
                                        children: caminos.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3EFq1iI",
                                        rel: "noreferrer",
                                        className: (mapa_module_default()).boton_como_llegar,
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${caminos.result?.international_phone_number}`,
                                        className: (mapa_module_default()).telefono_popup,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            caminos.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (mapa_module_default()).boton_ver_mas,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "caminos",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.705431599999997,
                            latitude: 40.4121929,
                            onClick: ()=>{
                                toggleTab(4);
                                onSelectTirso();
                            }
                        }),
                        showPopup === 4 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -35
                            },
                            longitude: -3.705431599999997,
                            latitude: 40.4121929,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (mapa_module_default()).contenedor_popuop,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Tirso de molina"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3tFiXwm",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: (mapa_module_default()).direccion_popup,
                                        children: tirso.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3tFiXwm",
                                        rel: "noreferrer",
                                        className: (mapa_module_default()).boton_como_llegar,
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${tirso.result?.international_phone_number}`,
                                        className: (mapa_module_default()).telefono_popup,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            tirso.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (mapa_module_default()).boton_ver_mas,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "tirso",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.698444600000016,
                            latitude: 40.4603827,
                            onClick: ()=>{
                                toggleTab(5);
                                onSelectTetuan();
                            }
                        }),
                        showPopup === 5 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -35
                            },
                            longitude: -3.698444600000016,
                            latitude: 40.4603827,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (mapa_module_default()).contenedor_popuop,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Tetu\xe1n"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3tFiXwm",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: (mapa_module_default()).direccion_popup,
                                        children: tetuan.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3tFiXwm",
                                        rel: "noreferrer",
                                        className: (mapa_module_default()).boton_como_llegar,
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${tetuan.result?.international_phone_number}`,
                                        className: (mapa_module_default()).telefono_popup,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            tetuan.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (mapa_module_default()).boton_ver_mas,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "tetuan",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.665292000000022,
                            latitude: 40.429553,
                            onClick: ()=>{
                                toggleTab(6);
                                onSelectAlcala();
                            }
                        }),
                        showPopup === 6 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -35
                            },
                            longitude: -3.665292000000022,
                            latitude: 40.429553,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (mapa_module_default()).contenedor_popuop,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Alcala-Ventas"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (mapa_module_default()).nombre_ciudad_popup,
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3THXcpZ",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: (mapa_module_default()).direccion_popup,
                                        children: alcala.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3THXcpZ",
                                        rel: "noreferrer",
                                        className: (mapa_module_default()).boton_como_llegar,
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${alcala.result?.international_phone_number}`,
                                        className: (mapa_module_default()).telefono_popup,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            alcala.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (mapa_module_default()).boton_ver_mas,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "alcala",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (mapa_module_default()).contenedor_info_mapa,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                    children: [
                        "Encuentra ",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "tu tienda m\xe1s cercana"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(accordion_Accordion2, {
                onSelectSantantoni: onSelectSantantoni,
                onSelectAlcala: onSelectAlcala,
                onSelectTetuan: onSelectTetuan,
                onSelectCaminos: onSelectCaminos,
                onSelectBernardo: onSelectBernardo,
                onSelectTirso: onSelectTirso,
                onSelectDelicias: onSelectDelicias,
                showPopup: showPopup,
                setShowPopup: setShowPopup,
                setViewState: setViewState,
                santantoni: santantoni,
                tirso: tirso,
                alcala: alcala,
                bernardo: bernardo,
                caminos: caminos,
                tetuan: tetuan,
                delicias: delicias
            })
        ]
    });
};
/* harmony default export */ const mapa_Mapa = (Mapa);


/***/ }),

/***/ 5544:
/***/ (() => {



/***/ })

};
;