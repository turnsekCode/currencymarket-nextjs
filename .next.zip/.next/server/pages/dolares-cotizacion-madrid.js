(() => {
var exports = {};
exports.id = 211;
exports.ids = [211];
exports.modules = {

/***/ 3433:
/***/ ((module) => {

// Exports
module.exports = {
	"img_stars": "accordion2_img_stars__yCw8V",
	"imgValoracion": "accordion2_imgValoracion__r6bPv",
	"logo_google": "accordion2_logo_google__bsVS1",
	"contenedor_google_accordion": "accordion2_contenedor_google_accordion__gAToF",
	"nombre_tienda": "accordion2_nombre_tienda__A4CbC",
	"contenedor_resenas": "accordion2_contenedor_resenas__nudyX",
	"numero_reviews": "accordion2_numero_reviews__2oa7n",
	"contacto_accordion": "accordion2_contacto_accordion__ePAoa",
	"direccion_accordion": "accordion2_direccion_accordion__J9LVW",
	"telefono_accordion": "accordion2_telefono_accordion__1IeD_",
	"contenedor_horarios": "accordion2_contenedor_horarios__Jya24",
	"contenedor_accordion": "accordion2_contenedor_accordion__bVIoz",
	"css-1fjvggn-MuiPaper-root-MuiAccordion-root": "accordion2_css-1fjvggn-MuiPaper-root-MuiAccordion-root__RwVvw",
	"contenedor_accordion2": "accordion2_contenedor_accordion2__F098t",
	"contenedor_accordion2_active": "accordion2_contenedor_accordion2_active__lpGJB",
	"cabecera_estrellas": "accordion2_cabecera_estrellas__ijJaQ",
	"cabecera_estrellas_active": "accordion2_cabecera_estrellas_active__0sDlf",
	"contenedor_titulo_accordion": "accordion2_contenedor_titulo_accordion__M0EHH",
	"active": "accordion2_active___Tjhx",
	"boton_cierre": "accordion2_boton_cierre__Q_iUd"
};


/***/ }),

/***/ 4910:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedor_mapa": "mapa_contenedor_mapa__viYPL",
	"mapa": "mapa_mapa__7_5K5",
	"market_img": "mapa_market_img__OxFZs",
	"titulo_mapa": "mapa_titulo_mapa__oyv1V",
	"contenedor_info_mapa": "mapa_contenedor_info_mapa__aNrIt",
	"boton_encontrar": "mapa_boton_encontrar__a3TM8",
	"conenedor_info_tienda": "mapa_conenedor_info_tienda__rV8ce",
	"conenedor_info_tienda_show": "mapa_conenedor_info_tienda_show___nCnc",
	"nombre_ciudad": "mapa_nombre_ciudad__UNSof",
	"item": "mapa_item__7ejQ5",
	"popup-delicias": "mapa_popup-delicias__S_iiH",
	"mapboxgl-popup-close-button": "mapa_mapboxgl-popup-close-button__lt7V6",
	"nombre_ciudad_popup": "mapa_nombre_ciudad_popup__r5cm_",
	"direccion_popup": "mapa_direccion_popup__8L0b0",
	"contenedor_popuop": "mapa_contenedor_popuop__rgQPZ",
	"telefono_popup": "mapa_telefono_popup__Z4ibJ",
	"boton_como_llegar": "mapa_boton_como_llegar__WPoPE",
	"boton_ver_mas": "mapa_boton_ver_mas__a35u0",
	"reset_map": "mapa_reset_map__UlVe_"
};


/***/ }),

/***/ 3864:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/styles/Home.module.css
var Home_module = __webpack_require__(1828);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: ./src/componentes/popup google/PopupGoogle.js
var PopupGoogle = __webpack_require__(7975);
// EXTERNAL MODULE: ./src/componentes/mapa_madrid/mapa.module.css
var mapa_module = __webpack_require__(4910);
var mapa_module_default = /*#__PURE__*/__webpack_require__.n(mapa_module);
// EXTERNAL MODULE: ./node_modules/animate.css/animate.css
var animate = __webpack_require__(5544);
// EXTERNAL MODULE: external "react-map-gl"
var external_react_map_gl_ = __webpack_require__(5372);
var external_react_map_gl_default = /*#__PURE__*/__webpack_require__.n(external_react_map_gl_);
// EXTERNAL MODULE: ./public/assets/logo-Google_1.png
var logo_Google_1 = __webpack_require__(1976);
// EXTERNAL MODULE: external "@mui/icons-material/ArrowForwardIos"
var ArrowForwardIos_ = __webpack_require__(1658);
var ArrowForwardIos_default = /*#__PURE__*/__webpack_require__.n(ArrowForwardIos_);
// EXTERNAL MODULE: ./src/componentes/accordion_madrid/accordion2.module.css
var accordion2_module = __webpack_require__(3433);
var accordion2_module_default = /*#__PURE__*/__webpack_require__.n(accordion2_module);
// EXTERNAL MODULE: external "@mui/icons-material/HighlightOff"
var HighlightOff_ = __webpack_require__(6380);
var HighlightOff_default = /*#__PURE__*/__webpack_require__.n(HighlightOff_);
// EXTERNAL MODULE: external "react-scroll"
var external_react_scroll_ = __webpack_require__(3094);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/componentes/accordion_madrid/Accordion2.js








const Accordion2 = ({ showPopup , setShowPopup , onSelectAlcala , onSelectDelicias , onSelectTetuan , onSelectBernardo , onSelectTirso , onSelectCaminos , tirso , alcala , bernardo , caminos , tetuan , delicias  })=>{
    const horarios = delicias?.result?.opening_hours?.weekday_text;
    const listaHorarios = horarios?.map((number, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
            className: `dia_${i++}`,
            children: number
        }, i));
    const resenas = delicias?.result?.rating;
    if (resenas > 4.7) {
        var img_valoracion = 69;
    } else if (resenas < 4.8 && resenas < 4.3) {
        var img_valoracion = 62;
    } else if (resenas < 4.4 && resenas < 3.7) {
        var img_valoracion = 55;
    } else if (resenas < 3.8 && resenas < 3.3) {
        var img_valoracion = 48;
    } else if (resenas < 3.4 && resenas < 2.7) {
        var img_valoracion = 41;
    } else if (resenas < 2.8 && resenas < 2.3) {
        var img_valoracion = 34;
    } else if (resenas < 2.4 && resenas < 1.7) {
        var img_valoracion = 27;
    } else if (resenas < 1.8 && resenas < 1.3) {
        var img_valoracion = 20;
    } else if (resenas < 1.4 && resenas < 0.7) {
        var img_valoracion = 13;
    }
    const toggleTab = (index)=>{
        setShowPopup(index);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                id: "delicias",
                className: showPopup === 1 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                        to: "contendor_mapa",
                        smooth: true,
                        offset: -110,
                        spy: true,
                        duration: 500,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            onClick: ()=>{
                                toggleTab(1);
                                onSelectDelicias();
                            },
                            className: (accordion2_module_default()).nombre_tienda,
                            children: delicias?.result?.name
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 1 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 1 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: delicias?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: delicias?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3X3XYRj",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: delicias?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${delicias?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: delicias?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "contendor_mapa",
                smooth: true,
                offset: -110,
                duration: 500,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        toggleTab(4);
                        onSelectTirso();
                    },
                    id: "tirso",
                    className: showPopup === 4 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: (accordion2_module_default()).nombre_tienda,
                            children: tirso?.result?.name
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 4 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 4 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: tirso?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: tirso?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3tFiXwm",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: tirso?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${tirso?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: tirso?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "contendor_mapa",
                smooth: true,
                offset: -110,
                duration: 500,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        toggleTab(3);
                        onSelectCaminos();
                    },
                    id: "caminos",
                    className: showPopup === 3 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: (accordion2_module_default()).nombre_tienda,
                            children: caminos?.result?.name
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 3 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 3 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: caminos?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: caminos?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3EFq1iI",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: caminos?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${caminos?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: caminos?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "contendor_mapa",
                smooth: true,
                offset: -110,
                duration: 500,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        toggleTab(2);
                        onSelectBernardo();
                    },
                    id: "bernardo",
                    className: showPopup === 2 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: (accordion2_module_default()).nombre_tienda,
                            children: bernardo?.result?.name
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 2 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 2 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: bernardo?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: bernardo?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3V13uCi",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: bernardo?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${bernardo?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: bernardo?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "contendor_mapa",
                smooth: true,
                offset: -110,
                duration: 500,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        toggleTab(6);
                        onSelectAlcala();
                    },
                    id: "alcala",
                    className: showPopup === 6 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: (accordion2_module_default()).nombre_tienda,
                            children: alcala?.result?.name
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 6 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 6 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: alcala?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: alcala?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3THXcpZ",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: alcala?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${alcala?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: alcala?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "contendor_mapa",
                smooth: true,
                offset: -110,
                duration: 500,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>{
                        //handleChange(5);
                        //setShowPopup(null);
                        toggleTab(5);
                        onSelectTetuan();
                    },
                    id: "tetuan",
                    className: showPopup === 5 ? `${(accordion2_module_default()).contenedor_titulo_accordion} ${(accordion2_module_default()).active}` : `${(accordion2_module_default()).contenedor_titulo_accordion}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowForwardIos_default()), {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: (accordion2_module_default()).nombre_tienda,
                            children: tetuan?.result?.name
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showPopup === 5 ? `${(accordion2_module_default()).contenedor_accordion2_active}` : `${(accordion2_module_default()).contenedor_accordion2}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: showPopup === 5 ? `${(accordion2_module_default()).cabecera_estrellas_active}` : `${(accordion2_module_default()).cabecera_estrellas}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (accordion2_module_default()).boton_cierre,
                            onClick: ()=>{
                                setShowPopup(false);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((HighlightOff_default()), {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_google_accordion,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (accordion2_module_default()).logo_google,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: logo_Google_1/* default */.Z,
                                        alt: "Logo google",
                                        width: 100,
                                        height: 56
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (accordion2_module_default()).contenedor_resenas,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: tetuan?.result?.rating
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (accordion2_module_default()).img_stars,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                style: {
                                                    width: img_valoracion
                                                },
                                                className: (accordion2_module_default()).imgValoracion
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (accordion2_module_default()).numero_reviews,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: tetuan?.result?.user_ratings_total
                                                }),
                                                " rese\xf1as de Google"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Contacto:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "http://bit.ly/3EgcXPx",
                                    rel: "noreferrer",
                                    target: "_blank",
                                    className: (accordion2_module_default()).direccion_accordion,
                                    children: tetuan?.result?.formatted_address
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: `tel:${tetuan?.result?.international_phone_number}`,
                                    className: (accordion2_module_default()).telefono_accordion,
                                    children: tetuan?.result?.international_phone_number
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (accordion2_module_default()).contenedor_horarios,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (accordion2_module_default()).contacto_accordion,
                                    children: "Horarios:"
                                }),
                                " ",
                                listaHorarios
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const accordion_madrid_Accordion2 = (Accordion2);

;// CONCATENATED MODULE: ./src/componentes/mapa_madrid/Mapa.js







const Mapa = ({ tirso , alcala , bernardo , caminos , tetuan , delicias  })=>{
    const [showPopup, setShowPopup] = (0,external_react_.useState)(null);
    const [viewState, setViewState] = (0,external_react_.useState)({
        longitude: -3.6883264,
        latitude: 40.4535878,
        zoom: 11,
        cooperativeGestures: true
    });
    const toggleTab = (index)=>{
        setShowPopup(index);
    };
    const mapRef = (0,external_react_.useRef)();
    const onSelectDelicias = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.6951906,
                40.4211045
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const onSelectTirso = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.705431599999997,
                40.4221929
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const onSelectTetuan = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.698444600000016,
                40.4703827
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const onSelectAlcala = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.665292000000022,
                40.439553
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const onSelectBernardo = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.7073656999999685,
                40.4332377
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const onSelectCaminos = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.7039902999999867,
                40.4588839
            ],
            duration: 1500,
            zoom: 11
        });
    };
    const resetMap = ()=>{
        mapRef.current?.flyTo({
            center: [
                -3.6951906,
                40.4535878
            ],
            duration: 1500,
            zoom: 11
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                className: (mapa_module_default()).titulo_mapa,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "\xbfD\xf3nde cambiar euros a d\xf3lares?"
                    }),
                    " Casas de Cambio en Barcelona"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "contendor_mapa",
                className: (mapa_module_default()).contenedor_mapa,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_map_gl_default()), {
                    ref: mapRef,
                    ...viewState,
                    onMove: (evt)=>setViewState(evt.viewState),
                    className: (mapa_module_default()).mapa,
                    mapStyle: "mapbox://styles/mapbox/streets-v9",
                    mapboxAccessToken: "pk.eyJ1IjoicXVpY2tnb2wiLCJhIjoiY2xhbGNvcHAyMDRyNjNwbWthcm1zMm9nbyJ9.tmZYhqn4Z6U3fcCZH647Zw",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.FullscreenControl, {}),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.GeolocateControl, {}),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.NavigationControl, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: (mapa_module_default()).reset_map,
                            onClick: ()=>{
                                resetMap();
                            },
                            children: "Reset Map"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.6951906,
                            latitude: 40.4011045,
                            onClick: ()=>{
                                toggleTab(1);
                                onSelectDelicias();
                            }
                        }),
                        showPopup === 1 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -25
                            },
                            longitude: -3.6951906,
                            className: "popup",
                            latitude: 40.4011045,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "contenedor_popuop",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Delicias"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3X3XYRj",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: "direccion_popup",
                                        children: delicias.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3X3XYRj",
                                        rel: "noreferrer",
                                        ƒ: true,
                                        className: "boton_como_llegar",
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${delicias.result?.international_phone_number}`,
                                        className: "telefono_popup",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            delicias.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "boton_ver_mas",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "delicias",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.7073656999999685,
                            latitude: 40.4232377,
                            onClick: ()=>{
                                toggleTab(2);
                                onSelectBernardo();
                            }
                        }),
                        showPopup === 2 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -35
                            },
                            longitude: -3.7073656999999685,
                            latitude: 40.4232377,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "contenedor_popuop",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "San Bernardo"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3V13uCi",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: "direccion_popup",
                                        children: bernardo.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3V13uCi",
                                        rel: "noreferrer",
                                        className: "boton_como_llegar",
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${bernardo.result?.international_phone_number}`,
                                        className: "telefono_popup",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            bernardo.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "boton_ver_mas",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "bernardo",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.7039902999999867,
                            latitude: 40.4488839,
                            onClick: ()=>{
                                toggleTab(3);
                                onSelectCaminos();
                            }
                        }),
                        showPopup === 3 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -35
                            },
                            longitude: -3.7039902999999867,
                            latitude: 40.4488839,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "contenedor_popuop",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Cuatro Caminos"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3EFq1iI",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: "direccion_popup",
                                        children: caminos.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3EFq1iI",
                                        rel: "noreferrer",
                                        className: "boton_como_llegar",
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${caminos.result?.international_phone_number}`,
                                        className: "telefono_popup",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            caminos.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "boton_ver_mas",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "caminos",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.705431599999997,
                            latitude: 40.4121929,
                            onClick: ()=>{
                                toggleTab(4);
                                onSelectTirso();
                            }
                        }),
                        showPopup === 4 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -35
                            },
                            longitude: -3.705431599999997,
                            latitude: 40.4121929,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "contenedor_popuop",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Tirso de molina"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3tFiXwm",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: "direccion_popup",
                                        children: tirso.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3tFiXwm",
                                        rel: "noreferrer",
                                        className: "boton_como_llegar",
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${tirso.result?.international_phone_number}`,
                                        className: "telefono_popup",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            tirso.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "boton_ver_mas",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "tirso",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.698444600000016,
                            latitude: 40.4603827,
                            onClick: ()=>{
                                toggleTab(5);
                                onSelectTetuan();
                            }
                        }),
                        showPopup === 5 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -35
                            },
                            longitude: -3.698444600000016,
                            latitude: 40.4603827,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "contenedor_popuop",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Tetu\xe1n"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3tFiXwm",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: "direccion_popup",
                                        children: tetuan.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3tFiXwm",
                                        rel: "noreferrer",
                                        className: "boton_como_llegar",
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${tetuan.result?.international_phone_number}`,
                                        className: "telefono_popup",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            tetuan.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "boton_ver_mas",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "tetuan",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Marker, {
                            longitude: -3.665292000000022,
                            latitude: 40.429553,
                            onClick: ()=>{
                                toggleTab(6);
                                onSelectAlcala();
                            }
                        }),
                        showPopup === 6 && /*#__PURE__*/ jsx_runtime_.jsx(external_react_map_gl_.Popup, {
                            style: {
                                top: -35
                            },
                            longitude: -3.665292000000022,
                            latitude: 40.429553,
                            closeOnClick: false,
                            anchor: null,
                            onClose: ()=>setShowPopup(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "contenedor_popuop",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Alcala-Ventas"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "nombre_ciudad_popup",
                                        children: "Contacto:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3THXcpZ",
                                        rel: "noreferrer",
                                        target: "_blank",
                                        className: "direccion_popup",
                                        children: alcala.result?.formatted_address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://bit.ly/3THXcpZ",
                                        rel: "noreferrer",
                                        className: "boton_como_llegar",
                                        children: "C\xf3mo llegar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: `tel:${alcala.result?.international_phone_number}`,
                                        className: "telefono_popup",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Llamar: "
                                            }),
                                            alcala.result?.international_phone_number
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "boton_ver_mas",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                                            to: "alcala",
                                            smooth: true,
                                            offset: -110,
                                            spy: true,
                                            duration: 500,
                                            children: "Ver M\xe1s"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (mapa_module_default()).contenedor_info_mapa,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                    children: [
                        "Encuentra ",
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "tu tienda m\xe1s cercana"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(accordion_madrid_Accordion2, {
                onSelectAlcala: onSelectAlcala,
                onSelectTetuan: onSelectTetuan,
                onSelectCaminos: onSelectCaminos,
                onSelectBernardo: onSelectBernardo,
                onSelectTirso: onSelectTirso,
                onSelectDelicias: onSelectDelicias,
                showPopup: showPopup,
                setShowPopup: setShowPopup,
                setViewState: setViewState,
                tirso: tirso,
                alcala: alcala,
                bernardo: bernardo,
                caminos: caminos,
                tetuan: tetuan,
                delicias: delicias
            })
        ]
    });
};
/* harmony default export */ const mapa_madrid_Mapa = (Mapa);

// EXTERNAL MODULE: ./src/componentes/contenedor/Contenedor.js + 13 modules
var Contenedor = __webpack_require__(8115);
// EXTERNAL MODULE: ./src/componentes/conversor_google/ConversorGoogle.js + 3 modules
var ConversorGoogle = __webpack_require__(8370);
;// CONCATENATED MODULE: ./src/pages/dolares-cotizacion-madrid/index.js








function Home({ tirso , alcala , bernardo , caminos , tetuan , delicias  }) {
    const [open, setOpen] = (0,external_react_.useState)(null);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Cambia euros por d\xf3lares en Madrid - CurrencyMarket"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "En nuestras casas de cambio en Madrid puedes comprar d\xf3lares a precio de cotizaci\xf3n. Sin comisiones. Totalmente gratis. Recibe tus d\xf3lares en efectivo al momento."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Contenedor/* default */.Z, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("section", {
                        className: (Home_module_default()).contenedor_conversor
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ConversorGoogle/* default */.Z, {
                        open: open,
                        setOpen: setOpen
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(mapa_madrid_Mapa, {
                        tirso: tirso,
                        alcala: alcala,
                        bernardo: bernardo,
                        caminos: caminos,
                        tetuan: tetuan,
                        delicias: delicias
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(PopupGoogle/* default */.Z, {
                open: open,
                setOpen: setOpen
            })
        ]
    });
}
async function getStaticProps() {
    const ciudad2 = await fetch(`https://quickgold.es/archivos-cache/archivos-cache-gmb/cached-place_id-tirsodemolina.txt`);
    const tirso = await ciudad2.json();
    const ciudad3 = await fetch(`https://quickgold.es/archivos-cache/archivos-cache-gmb/cached-place_id-alcala.txt`);
    const alcala = await ciudad3.json();
    const ciudad4 = await fetch(`https://quickgold.es/archivos-cache/archivos-cache-gmb/cached-place_id-sanbernardo.txt`);
    const bernardo = await ciudad4.json();
    const ciudad5 = await fetch(`https://quickgold.es/archivos-cache/archivos-cache-gmb/cached-place_id-cuatrocaminos.txt`);
    const caminos = await ciudad5.json();
    const ciudad6 = await fetch(`https://quickgold.es/archivos-cache/archivos-cache-gmb/cached-place_id-tetuan.txt`);
    const tetuan = await ciudad6.json();
    const ciudad7 = await fetch(`https://quickgold.es/archivos-cache/archivos-cache-gmb/cached-place_id-delicias.txt`);
    const delicias = await ciudad7.json();
    // Pass data to the page via props
    return {
        props: {
            tirso,
            alcala,
            bernardo,
            caminos,
            tetuan,
            delicias
        },
        revalidate: 1
    };
}


/***/ }),

/***/ 1658:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ArrowForwardIos");

/***/ }),

/***/ 6380:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/HighlightOff");

/***/ }),

/***/ 550:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LocalPhone");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5372:
/***/ ((module) => {

"use strict";
module.exports = require("react-map-gl");

/***/ }),

/***/ 3094:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll");

/***/ }),

/***/ 5337:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll-to-top");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [443,61,115,770], () => (__webpack_exec__(3864)));
module.exports = __webpack_exports__;

})();